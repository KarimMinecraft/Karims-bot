# Karim Bot (mod Geode)

Bot level sederhana untuk Geometry Dash (Geode).

## Fitur
- **Record**: rekam setiap klik (beserta nomor frame) saat main, terutama di practice mode.
- **Mati di practice mode tidak masalah**: saat kamu mati dan balik ke checkpoint, klik setelah checkpoint otomatis dibuang. Yang tersimpan hanya run yang berhasil.
- **Simpan**: setelah Stop Rec, beri nama macro lalu simpan.
- **Load**: tombol Load membuka daftar macro tersimpan; pilih satu untuk dimuat (atau hapus).
- **Play**: putar ulang macro yang sudah dimuat/direkam.
- **Autosave**: kalau keluar level saat masih merekam, rekaman disimpan sebagai `autosave`.

Macro disimpan di folder save mod: `<folder save Geode>/karim.karim-bot/macros/*.kbot`
(format teks sederhana: `frame tombol down player1`).

## Cara pakai
1. Masuk level, buka **Practice Mode**.
2. Pause -> **Record**, lalu restart level dan main. Pasang checkpoint seperti biasa.
3. Selesai -> Pause -> **Stop Rec** -> beri nama -> **Simpan**.
4. Lain waktu: Pause -> **Load** -> pilih macro -> Pause -> **Play** -> restart level dari awal.

## Cara build
### Opsi A - GitHub Actions (tanpa install apa pun)
1. Buat repo GitHub baru, upload semua isi folder ini.
2. Tab **Actions** -> workflow **Build Karim Bot** (jalan otomatis saat push).
3. Setelah selesai, download artifact **Build Output** -> di dalamnya ada `karim.karim-bot.geode`.
4. Taruh file `.geode` di folder `geode/mods` di folder Geometry Dash (atau di Android: `Android/media/com.geode.launcher/game/geode/mods`).

### Opsi B - Build lokal
1. Install Geode CLI: https://docs.geode-sdk.org/getting-started/geode-cli
2. `geode sdk install` lalu `geode sdk install-binaries`
3. Di folder ini: `geode build` -> hasilnya `build/karim.karim-bot.geode`

## Catatan
- Target: GD 2.2074, Geode 4.x.
- Kode belum bisa dites langsung di game dari lingkungan ini. Kalau ada error compile (nama field/API beda versi), kirim lognya ke aku.
- Untuk sinkron sempurna, mulai Play dari awal level (restart dulu setelah menekan Play).
